طريقة الرفع على جيت هب (ريبو جديد):
1) ارفع الملف waled-ai-with-ads.zip في جذر الريبو كما هو (من غير فك).
2) أنشئ الملف .github/workflows/build-from-zip.yml والصق فيه محتوى الملف الموجود في هذا المجلد.
3) أضف الأسرار: ANDROID_KEYSTORE_BASE64 و ANDROID_KEYSTORE_PASSWORD و ANDROID_KEY_PASSWORD
   وفي Variables أضف: CAP_SERVER_URL
4) من تبويب Actions شغّل: Unzip and build signed APK + AAB
5) حمّل ملفات APK و AAB من Artifacts بعد انتهاء التشغيل.
