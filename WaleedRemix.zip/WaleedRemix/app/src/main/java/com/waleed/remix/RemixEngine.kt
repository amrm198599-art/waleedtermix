package com.waleed.remix

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Crop
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.VideoCompositorSettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File
import kotlin.math.max

const val CW = 1080
const val CH = 1920

enum class RemixMode { BASIC, HALF, THIRD, QUARTER, IMAGE }

/** Area as fractions of the canvas (0..1), origin top-left. */
data class Area(val l: Float, val t: Float, val r: Float, val b: Float) {
    val w get() = r - l
    val h get() = b - t
    val cx get() = (l + r) / 2f
    val cy get() = (t + b) / 2f
}

data class RemixLayout(val primary: Area, val secondary: Area)

object LayoutCalc {
    /**
     * BASIC: primary fills the screen, second video is a strip over the bottom 30%.
     * HALF/THIRD/QUARTER/IMAGE: screen is split; second takes 1/2, 1/3, 1/4, 2/5 (image).
     * swapped: second goes to the top and primary to the bottom.
     */
    fun compute(mode: RemixMode, swapped: Boolean): RemixLayout {
        val full = Area(0f, 0f, 1f, 1f)
        val f = when (mode) {
            RemixMode.BASIC -> 0.30f
            RemixMode.HALF -> 0.5f
            RemixMode.THIRD -> 1f / 3f
            RemixMode.QUARTER -> 0.25f
            RemixMode.IMAGE -> 0.4f
        }
        return if (mode == RemixMode.BASIC) {
            RemixLayout(full, if (!swapped) Area(0f, 1f - f, 1f, 1f) else Area(0f, 0f, 1f, f))
        } else if (!swapped) {
            RemixLayout(Area(0f, 0f, 1f, 1f - f), Area(0f, 1f - f, 1f, 1f))
        } else {
            RemixLayout(Area(0f, f, 1f, 1f), Area(0f, 0f, 1f, f))
        }
    }
}

data class VInfo(val w: Int, val h: Int, val durationUs: Long)

object MediaInfo {
    fun video(ctx: Context, uri: Uri): VInfo {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong()
            return VInfo(w, h, ms * 1000)
        } finally { r.release() }
    }

    fun loadBitmap(ctx: Context, uri: Uri): Bitmap? = try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { dec, info, _ ->
            val s = max(info.size.width, info.size.height) / 1600
            if (s > 1) dec.setTargetSampleSize(s)
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } catch (e: Exception) { null }
}

@OptIn(UnstableApi::class)
class RemixCompositorSettings(private val layout: RemixLayout) : VideoCompositorSettings {
    override fun getOutputSize(inputSizes: List<Size>): Size = Size(CW, CH)

    override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
        val a = if (inputId == 0) layout.primary else layout.secondary
        return OverlaySettings.Builder()
            .setScale(a.w, a.h)
            .setBackgroundFrameAnchor(2f * a.cx - 1f, 1f - 2f * a.cy)
            .build()
    }
}

@OptIn(UnstableApi::class)
class Exporter(private val ctx: Context) {
    private var transformer: Transformer? = null
    private val holder = ProgressHolder()

    /**
     * Each input is center-cropped to its area's aspect ratio, stretched to the full canvas,
     * then the compositor scales it down into its area. Result: no distortion, no black bars.
     */
    private fun effectsFor(srcW: Int, srcH: Int, a: Area): Effects {
        val target = (a.w * CW) / (a.h * CH)
        val src = srcW.toFloat() / srcH
        val crop = if (src > target) {
            val f = target / src; Crop(-f, f, -1f, 1f)
        } else {
            val f = src / target; Crop(-1f, 1f, -f, f)
        }
        return Effects(emptyList(), listOf(crop, Presentation.createForWidthAndHeight(CW, CH, Presentation.LAYOUT_STRETCH_TO_FIT)))
    }

    fun start(
        primary: Uri, second: Uri, secondIsImage: Boolean,
        mode: RemixMode, swapped: Boolean, out: File,
        onDone: (Throwable?) -> Unit
    ) {
        try {
            val layout = LayoutCalc.compute(mode, swapped)
            val p = MediaInfo.video(ctx, primary)
            val primaryItem = EditedMediaItem.Builder(MediaItem.fromUri(primary))
                .setEffects(effectsFor(p.w, p.h, layout.primary)).build()

            val secondItem = if (secondIsImage) {
                val bmp = MediaInfo.loadBitmap(ctx, second) ?: throw IllegalStateException("image")
                val fx = effectsFor(bmp.width, bmp.height, layout.secondary)
                bmp.recycle()
                EditedMediaItem.Builder(MediaItem.fromUri(second))
                    .setDurationUs(p.durationUs).setFrameRate(30).setEffects(fx).build()
            } else {
                val s = MediaInfo.video(ctx, second)
                EditedMediaItem.Builder(MediaItem.fromUri(second))
                    .setRemoveAudio(true)
                    .setEffects(effectsFor(s.w, s.h, layout.secondary)).build()
            }

            val seq1 = EditedMediaItemSequence.Builder(primaryItem).build()
            // A shorter second video loops until the main video ends; a longer one is cut.
            val seq2 = EditedMediaItemSequence.Builder(secondItem).setIsLooping(!secondIsImage).build()
            val composition = Composition.Builder(listOf(seq1, seq2))
                .setVideoCompositorSettings(RemixCompositorSettings(layout))
                .build()

            if (out.exists()) out.delete()
            val t = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(
                    DefaultEncoderFactory.Builder(ctx)
                        .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(10_000_000).build())
                        .build()
                )
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) = onDone(null)
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) = onDone(exportException)
                }).build()
            transformer = t
            t.start(composition, out.absolutePath)
        } catch (e: Exception) {
            onDone(e)
        }
    }

    fun progress(): Int {
        val t = transformer ?: return 0
        return if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) holder.progress else 0
    }

    fun cancel() { transformer?.cancel(); transformer = null }
}

object Gallery {
    fun save(ctx: Context, file: File): Uri? {
        val r = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "WaleedRemix_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Waleed Remix")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = r.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        return try {
            r.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
            v.clear(); v.put(MediaStore.Video.Media.IS_PENDING, 0)
            r.update(uri, v, null, null)
            uri
        } catch (e: Exception) { r.delete(uri, null, null); null }
    }
}
