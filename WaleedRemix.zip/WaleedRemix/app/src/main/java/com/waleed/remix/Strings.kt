package com.waleed.remix

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import java.util.Locale

enum class Lang(val code: String, val label: String, val flag: String, val rtl: Boolean = false) {
    AR("ar", "العربية", "🇸🇦", true),
    EN("en", "English", "🇬🇧"),
    FR("fr", "Français", "🇫🇷"),
    ES("es", "Español", "🇪🇸"),
    DE("de", "Deutsch", "🇩🇪"),
    TR("tr", "Türkçe", "🇹🇷"),
    IT("it", "Italiano", "🇮🇹"),
    PT("pt", "Português", "🇵🇹"),
    HI("hi", "हिन्दी", "🇮🇳");

    companion object {
        fun fromCode(c: String?): Lang =
            entries.firstOrNull { it.code == (c ?: Locale.getDefault().language) } ?: EN
    }
}

// The order of this enum MUST match the order of every list in Strings.data
enum class K {
    SUBTITLE, PICK_MAIN, PICK_SECOND, PICK_IMAGE, CHOOSE_LAYOUT,
    BASIC, HALF, THIRD, QUARTER, IMAGE,
    SWAP, SAVE_GALLERY, LANGUAGE, ABOUT, PRIVACY, SELECT_LANGUAGE, SAVE,
    EXPORTING, SAVED_TITLE, SAVED_SUB, OPEN_GALLERY, BACK_HOME,
    ERR_MAIN, ERR_SECOND, ERR_EXPORT, VERSION, MADE_TOGETHER,
    PRIVACY_BODY, CANCEL, LAYOUT_EXAMPLES, AGREE, LIMITS_NOTE, SHARE_APP
}

val LocalLang = compositionLocalOf { Lang.EN }

@Composable
fun s(k: K): String = Strings.get(LocalLang.current, k)

object Strings {
    fun get(l: Lang, k: K): String = data.getValue(l)[k.ordinal]

    private val data: Map<Lang, List<String>> = mapOf(
        Lang.AR to listOf(
            "وليد ريمكس", "رفع الفيديو الأساسي", "رفع الفيديو الثاني", "اختيار صورة", "اختر الشكل السفلي",
            "الأساسي", "نصف", "ثلث", "ربع", "صورة",
            "عكس الترتيب", "حفظ في المعرض", "اللغة", "حول التطبيق", "سياسة الخصوصية", "اختيار اللغة", "حفظ",
            "جارٍ تجهيز الفيديو…", "تم الحفظ بنجاح", "تم حفظ الفيديو في معرض الصور", "فتح في المعرض", "العودة للرئيسية",
            "اختر الفيديو الأساسي أولًا", "اختر الفيديو الثاني أو الصورة أولًا", "تعذّر تصدير الفيديو. جرّب ملفًا آخر.", "الإصدار", "معًا نصنع إبداعك",
            "يعالج التطبيق الفيديوهات والصور محليًا على هاتفك فقط، ولا يرفعها إلى أي خادم. لا نجمع أي بيانات شخصية ولا نشارك أي معلومات مع جهات خارجية. يصل التطبيق إلى الملفات التي تختارها أنت فقط، ويحفظ الناتج في معرض هاتفك.",
            "إلغاء", "أشكال التراك السفلي", "موافق", "قد يستغرق التصدير وقتًا أطول مع الفيديوهات الطويلة أو عالية الدقة. الناتج بدقة 1080×1920.", "مشاركة التطبيق"
        ),
        Lang.EN to listOf(
            "Waleed Remix", "Upload main video", "Upload second video", "Choose image", "Choose the bottom layout",
            "Basic", "Half", "Third", "Quarter", "Image",
            "Swap order", "Save to gallery", "Language", "About", "Privacy policy", "Choose language", "Save",
            "Preparing your video…", "Saved successfully", "Your video was saved to the gallery", "Open in gallery", "Back to home",
            "Choose the main video first", "Choose the second video or image first", "Couldn't export the video. Try another file.", "Version", "Creating together",
            "Waleed Remix processes your videos and images locally on your phone only and never uploads them to any server. We do not collect personal data and do not share information with third parties. The app can only access the files you choose, and saves the result to your gallery.",
            "Cancel", "Bottom layouts", "Agree", "Exporting can take longer for long or high-resolution videos. Output is 1080×1920.", "Share app"
        ),
        Lang.FR to listOf(
            "Waleed Remix", "Importer la vidéo principale", "Importer la deuxième vidéo", "Choisir une image", "Choisissez la disposition du bas",
            "Basique", "Moitié", "Tiers", "Quart", "Image",
            "Inverser l’ordre", "Enregistrer dans la galerie", "Langue", "À propos", "Politique de confidentialité", "Choisir la langue", "Enregistrer",
            "Préparation de la vidéo…", "Enregistré avec succès", "La vidéo a été enregistrée dans la galerie", "Ouvrir dans la galerie", "Retour à l’accueil",
            "Choisissez d’abord la vidéo principale", "Choisissez d’abord la deuxième vidéo ou une image", "Impossible d’exporter la vidéo. Essayez un autre fichier.", "Version", "Créons ensemble",
            "Waleed Remix traite vos vidéos et images uniquement en local sur votre téléphone et ne les envoie à aucun serveur. Nous ne collectons aucune donnée personnelle et ne partageons aucune information avec des tiers. L’application n’accède qu’aux fichiers que vous choisissez et enregistre le résultat dans votre galerie.",
            "Annuler", "Dispositions du bas", "D’accord", "L’exportation peut être plus longue pour les vidéos longues ou en haute résolution. Sortie en 1080×1920.", "Partager l’application"
        ),
        Lang.ES to listOf(
            "Waleed Remix", "Subir el vídeo principal", "Subir el segundo vídeo", "Elegir imagen", "Elige el diseño inferior",
            "Básico", "Mitad", "Tercio", "Cuarto", "Imagen",
            "Invertir orden", "Guardar en la galería", "Idioma", "Acerca de", "Política de privacidad", "Elegir idioma", "Guardar",
            "Preparando el vídeo…", "Guardado correctamente", "El vídeo se guardó en la galería", "Abrir en la galería", "Volver al inicio",
            "Elige primero el vídeo principal", "Elige primero el segundo vídeo o una imagen", "No se pudo exportar el vídeo. Prueba con otro archivo.", "Versión", "Creamos juntos",
            "Waleed Remix procesa tus vídeos e imágenes solo en tu teléfono y nunca los sube a ningún servidor. No recopilamos datos personales ni compartimos información con terceros. La aplicación solo accede a los archivos que eliges y guarda el resultado en tu galería.",
            "Cancelar", "Diseños inferiores", "Aceptar", "La exportación puede tardar más con vídeos largos o de alta resolución. Salida en 1080×1920.", "Compartir la app"
        ),
        Lang.DE to listOf(
            "Waleed Remix", "Hauptvideo hochladen", "Zweites Video hochladen", "Bild auswählen", "Unteres Layout wählen",
            "Basis", "Hälfte", "Drittel", "Viertel", "Bild",
            "Reihenfolge tauschen", "In Galerie speichern", "Sprache", "Über die App", "Datenschutzerklärung", "Sprache wählen", "Speichern",
            "Video wird vorbereitet…", "Erfolgreich gespeichert", "Das Video wurde in der Galerie gespeichert", "In Galerie öffnen", "Zurück zum Start",
            "Wähle zuerst das Hauptvideo", "Wähle zuerst das zweite Video oder ein Bild", "Das Video konnte nicht exportiert werden. Versuche eine andere Datei.", "Version", "Gemeinsam kreativ",
            "Waleed Remix verarbeitet deine Videos und Bilder ausschließlich lokal auf deinem Telefon und lädt sie nie auf einen Server hoch. Wir erheben keine personenbezogenen Daten und geben keine Informationen an Dritte weiter. Die App greift nur auf die von dir gewählten Dateien zu und speichert das Ergebnis in deiner Galerie.",
            "Abbrechen", "Untere Layouts", "Zustimmen", "Der Export kann bei langen oder hochauflösenden Videos länger dauern. Ausgabe in 1080×1920.", "App teilen"
        ),
        Lang.TR to listOf(
            "Waleed Remix", "Ana videoyu yükle", "İkinci videoyu yükle", "Resim seç", "Alt düzeni seçin",
            "Temel", "Yarım", "Üçte bir", "Dörtte bir", "Resim",
            "Sırayı değiştir", "Galeriye kaydet", "Dil", "Hakkında", "Gizlilik politikası", "Dil seçin", "Kaydet",
            "Video hazırlanıyor…", "Başarıyla kaydedildi", "Video galeriye kaydedildi", "Galeride aç", "Ana sayfaya dön",
            "Önce ana videoyu seçin", "Önce ikinci videoyu veya resmi seçin", "Video dışa aktarılamadı. Başka bir dosya deneyin.", "Sürüm", "Birlikte üretiyoruz",
            "Waleed Remix videolarınızı ve resimlerinizi yalnızca telefonunuzda yerel olarak işler ve hiçbir sunucuya yüklemez. Kişisel veri toplamayız ve üçüncü taraflarla bilgi paylaşmayız. Uygulama yalnızca sizin seçtiğiniz dosyalara erişir ve sonucu galerinize kaydeder.",
            "İptal", "Alt düzenler", "Kabul et", "Uzun veya yüksek çözünürlüklü videolarda dışa aktarma daha uzun sürebilir. Çıktı 1080×1920'dir.", "Uygulamayı paylaş"
        ),
        Lang.IT to listOf(
            "Waleed Remix", "Carica il video principale", "Carica il secondo video", "Scegli immagine", "Scegli il layout inferiore",
            "Base", "Metà", "Terzo", "Quarto", "Immagine",
            "Inverti ordine", "Salva nella galleria", "Lingua", "Informazioni", "Informativa sulla privacy", "Scegli la lingua", "Salva",
            "Preparazione del video…", "Salvato con successo", "Il video è stato salvato nella galleria", "Apri nella galleria", "Torna alla home",
            "Scegli prima il video principale", "Scegli prima il secondo video o un’immagine", "Impossibile esportare il video. Prova un altro file.", "Versione", "Creiamo insieme",
            "Waleed Remix elabora video e immagini solo in locale sul tuo telefono e non li carica su alcun server. Non raccogliamo dati personali e non condividiamo informazioni con terze parti. L’app accede solo ai file che scegli e salva il risultato nella tua galleria.",
            "Annulla", "Layout inferiori", "Accetto", "L’esportazione può richiedere più tempo con video lunghi o ad alta risoluzione. Uscita in 1080×1920.", "Condividi l’app"
        ),
        Lang.PT to listOf(
            "Waleed Remix", "Carregar vídeo principal", "Carregar segundo vídeo", "Escolher imagem", "Escolha o layout inferior",
            "Básico", "Metade", "Terço", "Quarto", "Imagem",
            "Inverter ordem", "Salvar na galeria", "Idioma", "Sobre", "Política de privacidade", "Escolher idioma", "Salvar",
            "Preparando o vídeo…", "Salvo com sucesso", "O vídeo foi salvo na galeria", "Abrir na galeria", "Voltar ao início",
            "Escolha primeiro o vídeo principal", "Escolha primeiro o segundo vídeo ou uma imagem", "Não foi possível exportar o vídeo. Tente outro arquivo.", "Versão", "Criamos juntos",
            "O Waleed Remix processa seus vídeos e imagens apenas localmente no seu telefone e nunca os envia a nenhum servidor. Não coletamos dados pessoais nem compartilhamos informações com terceiros. O app acessa apenas os arquivos que você escolhe e salva o resultado na sua galeria.",
            "Cancelar", "Layouts inferiores", "Concordo", "A exportação pode demorar mais com vídeos longos ou de alta resolução. Saída em 1080×1920.", "Compartilhar o app"
        ),
        Lang.HI to listOf(
            "वलीद रीमिक्स", "मुख्य वीडियो अपलोड करें", "दूसरा वीडियो अपलोड करें", "फ़ोटो चुनें", "निचला लेआउट चुनें",
            "बेसिक", "आधा", "एक-तिहाई", "एक-चौथाई", "फ़ोटो",
            "क्रम बदलें", "गैलरी में सहेजें", "भाषा", "ऐप के बारे में", "गोपनीयता नीति", "भाषा चुनें", "सहेजें",
            "वीडियो तैयार हो रहा है…", "सफलतापूर्वक सहेजा गया", "वीडियो गैलरी में सहेज दिया गया है", "गैलरी में खोलें", "होम पर वापस जाएँ",
            "पहले मुख्य वीडियो चुनें", "पहले दूसरा वीडियो या फ़ोटो चुनें", "वीडियो एक्सपोर्ट नहीं हो सका। कोई दूसरी फ़ाइल आज़माएँ।", "संस्करण", "मिलकर रचते हैं",
            "वलीद रीमिक्स आपके वीडियो और फ़ोटो को केवल आपके फ़ोन पर ही प्रोसेस करता है और उन्हें किसी सर्वर पर अपलोड नहीं करता। हम कोई व्यक्तिगत डेटा एकत्र नहीं करते और किसी तीसरे पक्ष के साथ जानकारी साझा नहीं करते। ऐप केवल उन्हीं फ़ाइलों तक पहुँचता है जिन्हें आप चुनते हैं और परिणाम आपकी गैलरी में सहेजता है।",
            "रद्द करें", "निचले लेआउट", "सहमत हूँ", "लंबे या हाई-रेज़ोल्यूशन वीडियो के एक्सपोर्ट में अधिक समय लग सकता है। आउटपुट 1080×1920 है।", "ऐप शेयर करें"
        )
    ).also { m -> m.forEach { (l, v) -> require(v.size == K.entries.size) { "Bad string count for $l: ${v.size}" } } }
}
