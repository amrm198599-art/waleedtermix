package com.waleed.remix

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Screen { SPLASH, HOME, LANGUAGE, EXAMPLES, EXPORTING, SUCCESS, ABOUT, PRIVACY }

class RemixState {
    var mainUri by mutableStateOf<Uri?>(null)
    var secondUri by mutableStateOf<Uri?>(null)
    var secondIsImage by mutableStateOf(false)
    var mode by mutableStateOf(RemixMode.BASIC)
    var swapped by mutableStateOf(false)

    fun changeMode(m: RemixMode) {
        mode = m
        if (secondUri != null && (m == RemixMode.IMAGE) != secondIsImage) secondUri = null
    }
}

@Composable
fun RemixApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("remix", 0) }
    var lang by remember { mutableStateOf(Lang.fromCode(prefs.getString("lang", null))) }
    var screen by remember { mutableStateOf(Screen.SPLASH) }
    var progress by remember { mutableIntStateOf(0) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    val st = remember { RemixState() }
    val exporter = remember { Exporter(ctx.applicationContext) }
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }

    fun toast(k: K) { scope.launch { snack.showSnackbar(Strings.get(lang, k)) } }

    fun startExport() {
        val m = st.mainUri
        val sec = st.secondUri
        if (m == null) { toast(K.ERR_MAIN); return }
        if (sec == null) { toast(K.ERR_SECOND); return }
        progress = 0
        screen = Screen.EXPORTING
        val out = File(ctx.cacheDir, "remix_${System.currentTimeMillis()}.mp4")
        exporter.start(m, sec, st.secondIsImage, st.mode, st.swapped, out) { err ->
            if (err != null) {
                out.delete(); screen = Screen.HOME; toast(K.ERR_EXPORT)
            } else scope.launch {
                val uri = withContext(Dispatchers.IO) { Gallery.save(ctx, out) }
                out.delete()
                if (uri != null) { savedUri = uri; screen = Screen.SUCCESS } else { screen = Screen.HOME; toast(K.ERR_EXPORT) }
            }
        }
        scope.launch { while (screen == Screen.EXPORTING) { progress = exporter.progress(); delay(250) } }
    }

    BackHandler(enabled = screen != Screen.HOME && screen != Screen.SPLASH && screen != Screen.EXPORTING) {
        screen = Screen.HOME
    }

    CompositionLocalProvider(
        LocalLang provides lang,
        LocalLayoutDirection provides if (lang.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Bg, onSurface = Color.White)) {
            Box(Modifier.fillMaxSize().background(Bg)) {
                Box(Modifier.fillMaxSize().systemBarsPadding()) {
                    when (screen) {
                        Screen.SPLASH -> SplashScreen { screen = Screen.HOME }
                        Screen.HOME -> HomeScreen(st, onExport = ::startExport, onNav = { screen = it })
                        Screen.LANGUAGE -> LanguageScreen(lang, onBack = { screen = Screen.HOME }) {
                            lang = it; prefs.edit().putString("lang", it.code).apply(); screen = Screen.HOME
                        }
                        Screen.EXAMPLES -> ExamplesScreen { screen = Screen.HOME }
                        Screen.EXPORTING -> ExportScreen(progress) { exporter.cancel(); screen = Screen.HOME }
                        Screen.SUCCESS -> SuccessScreen(savedUri, onHome = { screen = Screen.HOME })
                        Screen.ABOUT -> AboutScreen(onBack = { screen = Screen.HOME }, onPrivacy = { screen = Screen.PRIVACY })
                        Screen.PRIVACY -> PrivacyScreen { screen = Screen.HOME }
                    }
                    SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).padding(16.dp))
                }
            }
        }
    }
}
