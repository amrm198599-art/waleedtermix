package com.waleed.remix

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

val Blue = Color(0xFF2F80FF)
val Cyan = Color(0xFF1FB6FF)
val Purple = Color(0xFF8B5CF6)
val Magenta = Color(0xFFB45CFF)
val Bg = Color(0xFF0A0F1F)
val CardBg = Color(0xFF141B30)

@Composable
fun GradientButton(text: String, colors: List<Color>, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(colors)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center) }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Spacer(Modifier.width(48.dp))
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) { delay(1300); onDone() }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Logo(140)
        Spacer(Modifier.height(20.dp))
        Row { Text("Waleed ", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text("Remix", color = Blue, fontSize = 30.sp, fontWeight = FontWeight.Bold) }
        Text(s(K.SUBTITLE), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Logo(size: Int) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape((size / 4).dp))
            .background(Brush.linearGradient(listOf(Color(0xFF05081A), Color(0xFF1A1245))))
            .border(2.dp, Brush.linearGradient(listOf(Cyan, Magenta)), RoundedCornerShape((size / 4).dp)),
        contentAlignment = Alignment.Center
    ) {
        Text("W", fontSize = (size * 0.55f).sp, fontWeight = FontWeight.ExtraBold,
            style = TextStyle(brush = Brush.linearGradient(listOf(Cyan, Magenta)), fontSize = (size * 0.55f).sp, fontWeight = FontWeight.ExtraBold))
    }
}

/** Mini drawing of a layout (used in the mode selector and the examples screen). */
@Composable
fun LayoutThumb(mode: RemixMode, swapped: Boolean, modifier: Modifier) {
    val lay = LayoutCalc.compute(mode, swapped)
    BoxWithConstraints(modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF0E2A55))) {
        val W = maxWidth; val H = maxHeight
        Box(Modifier.size(W, H).background(Brush.verticalGradient(listOf(Color(0xFFFF9A5A), Color(0xFF2B4C8C)))))
        val a = lay.secondary
        Box(
            Modifier.offset(W * a.l, H * a.t).size(W * a.w, H * a.h)
                .background(if (mode == RemixMode.IMAGE) Magenta else Purple)
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerSurface(player: ExoPlayer) {
    AndroidView(
        factory = { c ->
            PlayerView(c).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                this.player = player
            }
        },
        update = { it.player = player },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
fun RemixPreview(st: RemixState, modifier: Modifier) {
    val ctx = LocalContext.current
    val layout = LayoutCalc.compute(st.mode, st.swapped)
    var playing by remember { mutableStateOf(false) }

    val mainPlayer = remember(st.mainUri) {
        st.mainUri?.let { u -> ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(u)); prepare() } }
    }
    val secPlayer = remember(st.secondUri, st.secondIsImage) {
        val u = st.secondUri
        if (u != null && !st.secondIsImage) ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(u)); repeatMode = Player.REPEAT_MODE_ONE; volume = 0f; prepare()
        } else null
    }
    DisposableEffect(mainPlayer) { onDispose { mainPlayer?.release() } }
    DisposableEffect(secPlayer) { onDispose { secPlayer?.release() } }
    DisposableEffect(mainPlayer, secPlayer) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) { playing = false; mainPlayer?.seekTo(0); secPlayer?.seekTo(0) }
            }
        }
        mainPlayer?.addListener(l)
        onDispose { mainPlayer?.removeListener(l) }
    }
    LaunchedEffect(playing, mainPlayer, secPlayer) {
        mainPlayer?.playWhenReady = playing
        secPlayer?.playWhenReady = playing
    }
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, st.secondUri, st.secondIsImage) {
        val u = st.secondUri
        value = if (u != null && st.secondIsImage) withContext(Dispatchers.IO) { MediaInfo.loadBitmap(ctx, u)?.asImageBitmap() } else null
    }

    BoxWithConstraints(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color.Black)
            .clickable(enabled = mainPlayer != null) { playing = !playing }
    ) {
        val W = maxWidth; val H = maxHeight
        @Composable
        fun Slot(a: Area, content: @Composable () -> Unit) {
            Box(Modifier.offset(W * a.l, H * a.t).size(W * a.w, H * a.h).clipToBounds()) { content() }
        }
        Slot(layout.primary) {
            if (mainPlayer != null) PlayerSurface(mainPlayer)
            else Box(Modifier.fillMaxSize().background(CardBg), contentAlignment = Alignment.Center) {
                Text(s(K.PICK_MAIN), color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(8.dp))
            }
        }
        Slot(layout.secondary) {
            when {
                secPlayer != null -> PlayerSurface(secPlayer)
                bmp != null -> Image(bmp!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else -> Box(Modifier.fillMaxSize().background(Color(0xFF1B1340)), contentAlignment = Alignment.Center) {
                    Text(if (st.mode == RemixMode.IMAGE) s(K.PICK_IMAGE) else s(K.PICK_SECOND), color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(8.dp))
                }
            }
        }
        if (mainPlayer != null && !playing) {
            Box(Modifier.align(Alignment.Center).size(56.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(36.dp))
            }
        }
    }
}

@Composable
fun HomeScreen(st: RemixState, onExport: () -> Unit, onNav: (Screen) -> Unit) {
    val pickMain = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u -> if (u != null) st.mainUri = u }
    val pickSecond = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) { st.secondUri = u; st.secondIsImage = st.mode == RemixMode.IMAGE }
    }
    val modes = listOf(RemixMode.BASIC to K.BASIC, RemixMode.HALF to K.HALF, RemixMode.THIRD to K.THIRD, RemixMode.QUARTER to K.QUARTER, RemixMode.IMAGE to K.IMAGE)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Waleed ", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Remix", color = Blue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        GradientButton((if (st.mainUri != null) "✓  " else "") + s(K.PICK_MAIN), listOf(Blue, Cyan)) {
            pickMain.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
        }
        Spacer(Modifier.height(14.dp))
        RemixPreview(st, Modifier.fillMaxWidth(0.55f).aspectRatio(9f / 16f))
        Spacer(Modifier.height(14.dp))

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardBg).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(s(K.CHOOSE_LAYOUT), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = { onNav(Screen.EXAMPLES) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Info, null, tint = Cyan) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                modes.forEach { (m, k) ->
                    val sel = st.mode == m
                    Column(
                        Modifier.weight(1f).padding(3.dp).clip(RoundedCornerShape(10.dp))
                            .border(if (sel) 2.dp else 1.dp, if (sel) Blue else Color(0xFF2A3354), RoundedCornerShape(10.dp))
                            .clickable { st.changeMode(m) }.padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        LayoutThumb(m, st.swapped, Modifier.size(width = 40.dp, height = 56.dp))
                        Spacer(Modifier.height(4.dp))
                        Text(s(k), color = if (sel) Color.White else Color.Gray, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { st.swapped = !st.swapped }, modifier = Modifier.fillMaxWidth()) {
                Text("⇅  " + s(K.SWAP), color = if (st.swapped) Cyan else Color.White)
            }
        }
        Spacer(Modifier.height(14.dp))
        val secLabel = if (st.mode == RemixMode.IMAGE) s(K.PICK_IMAGE) else s(K.PICK_SECOND)
        GradientButton((if (st.secondUri != null) "✓  " else "") + secLabel, listOf(Purple, Magenta)) {
            pickSecond.launch(PickVisualMediaRequest(
                if (st.mode == RemixMode.IMAGE) ActivityResultContracts.PickVisualMedia.ImageOnly else ActivityResultContracts.PickVisualMedia.VideoOnly))
        }
        Spacer(Modifier.height(10.dp))
        GradientButton(s(K.SAVE_GALLERY), listOf(Color(0xFF1565FF), Color(0xFF00C2FF)), onClick = onExport)
        Spacer(Modifier.height(6.dp))
        Text(s(K.LIMITS_NOTE), color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            NavItem("🌐", s(K.LANGUAGE)) { onNav(Screen.LANGUAGE) }
            NavItem("ⓘ", s(K.ABOUT)) { onNav(Screen.ABOUT) }
            NavItem("🛡", s(K.PRIVACY)) { onNav(Screen.PRIVACY) }
        }
    }
}

@Composable
fun NavItem(icon: String, label: String, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 22.sp)
        Text(label, color = Color.LightGray, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun LanguageScreen(current: Lang, onBack: () -> Unit, onSave: (Lang) -> Unit) {
    var sel by remember { mutableStateOf(current) }
    Column(Modifier.fillMaxSize()) {
        TopBar(s(K.SELECT_LANGUAGE), onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Lang.entries.forEach { l ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
                        .background(if (sel == l) Color(0xFF1B2A55) else CardBg).clickable { sel = l }.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(l.flag, fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(l.label, color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    RadioButton(selected = sel == l, onClick = { sel = l })
                }
            }
        }
        Box(Modifier.padding(16.dp)) {
            GradientButton(Strings.get(sel, K.SAVE), listOf(Blue, Cyan)) { onSave(sel) }
        }
    }
}

@Composable
fun ExamplesScreen(onBack: () -> Unit) {
    val items = listOf(RemixMode.BASIC to K.BASIC, RemixMode.THIRD to K.THIRD, RemixMode.QUARTER to K.QUARTER, RemixMode.IMAGE to K.IMAGE, RemixMode.HALF to K.HALF)
    Column(Modifier.fillMaxSize()) {
        TopBar(s(K.LAYOUT_EXAMPLES), onBack)
        LazyGrid2(items)
    }
}

@Composable
private fun LazyGrid2(items: List<Pair<RemixMode, K>>) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (m, k) ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(CardBg).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        LayoutThumb(m, false, Modifier.fillMaxWidth().aspectRatio(9f / 14f))
                        Spacer(Modifier.height(8.dp))
                        Text(s(k), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun ExportScreen(progress: Int, onCancel: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(progress = { progress / 100f }, modifier = Modifier.size(120.dp), strokeWidth = 8.dp, color = Blue)
            Text("$progress%", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(24.dp))
        Text(s(K.EXPORTING), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(s(K.LIMITS_NOTE), color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = onCancel) { Text(s(K.CANCEL), color = Color.White) }
    }
}

@Composable
fun SuccessScreen(uri: Uri?, onHome: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(Color(0xFF22C55E)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(60.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text(s(K.SAVED_TITLE), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(s(K.SAVED_SUB), color = Color.LightGray, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        OutlinedButton(onClick = {
            uri?.let {
                ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(s(K.OPEN_GALLERY), color = Color.White) }
        Spacer(Modifier.height(12.dp))
        GradientButton(s(K.BACK_HOME), listOf(Blue, Cyan), onClick = onHome)
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit, onPrivacy: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        TopBar(s(K.ABOUT), onBack)
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Logo(96)
            Spacer(Modifier.height(12.dp))
            Row { Text("Waleed ", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Remix", color = Blue, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            Text(s(K.SUBTITLE), color = Color.White, fontSize = 18.sp)
            Text(s(K.VERSION) + " 1.0", color = Color.Gray, fontSize = 13.sp)
            Spacer(Modifier.height(20.dp))
            AboutRow(Icons.Default.Lock, s(K.PRIVACY), onPrivacy)
            AboutRow(Icons.Default.Share, s(K.SHARE_APP)) {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Waleed Remix")
                ctx.startActivity(Intent.createChooser(i, null))
            }
            Spacer(Modifier.height(24.dp))
            Text(s(K.MADE_TOGETHER) + " 💜", color = Color.Gray, fontSize = 13.sp)
        }
    }
}

@Composable
private fun AboutRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp)).background(CardBg).clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Cyan)
        Spacer(Modifier.width(12.dp))
        Text(label, color = Color.White, fontSize = 16.sp)
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar(s(K.PRIVACY), onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Text(s(K.PRIVACY) + " – Waleed Remix", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(s(K.PRIVACY_BODY), color = Color.LightGray, fontSize = 15.sp, lineHeight = 24.sp)
        }
        Box(Modifier.padding(16.dp)) { GradientButton(s(K.AGREE), listOf(Blue, Cyan), onClick = onBack) }
    }
}
