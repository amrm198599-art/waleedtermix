# Waleed Remix (وليد ريمكس)
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, run on a device (Android 10+).
Kotlin + Jetpack Compose + AndroidX Media3 (ExoPlayer preview, Transformer export).
Languages: ar, en, fr, es, de, tr, it, pt, hi. Edit texts in Strings.kt.
Exports are saved to Movies/Waleed Remix.
